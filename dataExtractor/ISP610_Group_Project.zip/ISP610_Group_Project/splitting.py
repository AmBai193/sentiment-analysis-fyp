import pandas as pd
from sklearn.model_selection import train_test_split


def split_dataset(input_file, text_column='comment', label_column='True_label',
                  train_output='train_dataset_adidas_youtube_labelled.csv', test_output='test_dataset_adidas_youtube_labelled.csv'):
    def split_dataset(input_file, text_column='comment', label_column='True_label',
                      train_output='train_dataset_adidas_youtube_labelled.csv',
                      test_output='test_dataset_adidas_youtube_labelled.csv'):
        # Load dataset
        df = pd.read_csv(input_file)

        # Optional: drop rows with missing values in key columns
        df = df.dropna(subset=[text_column, label_column])

        # Count samples per class and filter out classes with < 2 samples
        value_counts = df[label_column].value_counts()
        valid_classes = value_counts[value_counts >= 2].index
        df = df[df[label_column].isin(valid_classes)]

        # Split into training and testing
        train_df, test_df = train_test_split(df, test_size=0.3, random_state=42, stratify=df[label_column])

        # Save to CSV
        train_df.to_csv(train_output, index=False)
        test_df.to_csv(test_output, index=False)

        print(f"Training set saved to '{train_output}' ({len(train_df)} rows)")
        print(f"Testing set saved to '{test_output}' ({len(test_df)} rows)")
# Example usage
if __name__ == '__main__':
    split_dataset('preprocessed_dataset_adidas_youtube_labelled.csv')