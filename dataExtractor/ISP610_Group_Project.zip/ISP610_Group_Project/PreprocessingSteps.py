import pandas as pd
import re

# Comprehensive contractions dictionary with word boundaries
CONTRACTIONS_DICT = {
    r"\bwon't\b": "will not",
    r"\bcan't\b": "cannot",
    r"\bcan\'t\b": "cannot",
    r"\bn\'t\b": " not",
    r"\b\'re\b": " are",
    r"\b\'s\b": " is",
    r"\b\'d\b": " would",
    r"\b\'ll\b": " will",
    r"\b\'t\b": " not",
    r"\b\'ve\b": " have",
    r"\b\'m\b": " am",
    r"\bdon't\b": "do not",
    r"\bDon't\b": "Do not",
    r"\bdoesn't\b": "does not",
    r"\bisn't\b": "is not",
    r"\bhe's\b": "he is",
    r"\bwasn't\b": "was not",
    r"\bthere's\b": "there is",
    r"\bcouldn't\b": "could not",
    r"\bthey're\b": "they are",
    r"\bshe's\b": "she is",
    r"\bThere's\b": "there is",
    r"\bwouldn't\b": "would not",
    r"\bhaven't\b": "have not",
    r"\bThat's\b": "that is",
    r"\byou've\b": "you have",
    r"\bHe's\b": "he is",
    r"\bwhat's\b": "what is",
    r"\bweren't\b": "were not",
    r"\bwe're\b": "we are",
    r"\bhasn't\b": "has not",
    r"\byou'd\b": "you would",
    r"\bshouldn't\b": "should not",
    r"\blet's\b": "let us",
    r"\bthey've\b": "they have",
    r"\bYou'll\b": "you will",
    r"\bi'm\b": "i am",
    r"\bwe've\b": "we have",
    r"\bit's\b": "it is",
    r"\bthat´s\b": "that is",
    r"\bI´m\b": "i am",
    r"\bshe´s\b": "she is",
    r"\bwitch\b": "which",
    r"\bdidn't\b": "did not",
    r"\bdoesn't\b": "does not",
    r"\bcouldn't\b": "could not",
    r"\bwouldn't\b": "would not",
    r"\bshouldn't\b": "should not",
    r"\bthey're\b": "they are",
    r"\bisn't\b": "is not",
    r"\baren't\b": "are not",
    r"\bI'm\b": "I am",
    r"\bI've\b": "I have",
    r"\bI'd\b": "I would",
    r"\bI'll\b": "I will",
    r"\byou're\b": "you are",
    r"\bthat's\b": "that is",
    r"\bthere's\b": "there is",
    r"\bthey've\b": "they have",
    r"\byou've\b": "you have",
    r"\by'all\b": "you all",
    r"\bwasn't\b": "was not",
    r"\bhaven't\b": "have not",
    r"\bwon't\b": "will not",
    r"\bty\b": "thank you",
    r"\bim\b": "I am",
    r"\bive\b": "I have",
    r"\bid\b": "I would",
    r"\bill\b": "I will",
    r"\byoure\b": "you are",
    r"\bthats\b": "that is",
    r"\btheres\b": "there is",
    r"\btheyve\b": "they have",
    r"\byouve\b": "you have",
    r"\bwasnt\b": "was not",
    r"\bhavent\b": "have not",
    r"\bwont\b": "will not"
}

# List of Adidas-related terms to preserve (case-insensitive)
ADIDAS_TERMS = [
    'adidas', 'adidasoriginals', 'adidassamba', 'samba', 'sambas',
    'yeezy', 'yeezys', 'yeezyboost', 'boost', 'ultraboost', 'nmd', 'superstar',
    'stan smith', 'stansmith', 'gazelle', 'forum', 'spezial', 'terrex', 'predator',
    'copa', 'nemeziz', 'xpeedition', 'ozweego', 'zx', 'falcon', 'deerupt',
    'pharrell', 'humanrace', 'eqt', 'continental', 'response', 'advantage',
    'adilette', 'adibreak', 'trefoil', 'badgeofsport', 'three stripes'
]

# Encoding fixes for corrupted text
ENCODING_FIXES = {
    r'„Ę‚ā¨‚ĄĘ': "'",
    r'„įŚłŽú‚Ä': '',
    r'„ÉŽÜs': "'s",
    r'„ā‚£': '£',
    r'„įŚł‚Ä?‚•': '',
    r'„įŚłŽú‚?': '',
    r'„įŚł‚Äė‚?': '',
    r'„įŚł‚ĄĘ‚?': "'",
    r'„Ę‚ā¨‚¶': "'",
    r'„įŚłŽú‚Äú': '"',
    r'„įŚłŽú‚Äö': '"',
    r'„Ę‚ā¨‚Äú': '"',
    r'„įŚł‚Äô‚™': "'",
    r'„įŚł‚Äô‚ā': "'"
}


def clean_encoding(text):
    """Clean corrupted unicode and fix encoding issues"""
    if not isinstance(text, str):
        return text

    # First remove all non-ASCII characters
    text = re.sub(r'[^\x00-\x7F]+', '', text)

    # Apply specific encoding fixes
    for pattern, replacement in ENCODING_FIXES.items():
        text = re.sub(pattern, replacement, text)

    return text


def preserve_brand_terms(text):
    """Replace Adidas terms with placeholders before processing"""
    if not isinstance(text, str):
        return text, {}

    placeholders = {}
    for i, term in enumerate(ADIDAS_TERMS):
        # Use regex substitution with a callback to handle case variations
        pattern = re.compile(rf'\b({re.escape(term)})\b', flags=re.IGNORECASE)

        def replacer(match):
            original_term = match.group(1)
            placeholder = f"ADIDAS_TERM_{i}_{abs(hash(original_term))}"
            placeholders[placeholder] = original_term
            return placeholder

        text = pattern.sub(replacer, text)
    return text, placeholders


def restore_brand_terms(text, placeholders):
    """Restore original Adidas terms from placeholders"""
    if not isinstance(text, str):
        return text

    for placeholder, term in placeholders.items():
        text = text.replace(placeholder, term)
    return text


def expand_contractions(text):
    """Expand contractions while protecting brand terms and whole words"""
    if not isinstance(text, str):
        return text

    # First preserve brand terms
    text, placeholders = preserve_brand_terms(text)

    # Process contractions with word boundaries
    for contraction, expansion in CONTRACTIONS_DICT.items():
        # Skip if contraction would interfere with placeholders
        if not any(contraction.lower() in p.lower() for p in placeholders):
            text = re.sub(contraction, expansion, text, flags=re.IGNORECASE)

    return restore_brand_terms(text, placeholders)


def clean_text(text):
    """
    Clean text while preserving Adidas terms
    """
    if not isinstance(text, str):
        return text

    # First clean encoding issues
    text = clean_encoding(text)

    # Then preserve brand terms
    text, placeholders = preserve_brand_terms(text)

    # Convert to lowercase (except placeholders)
    parts = []
    for part in re.split(r'(ADIDAS_TERM_\d+_\d+)', text):
        if part.startswith('ADIDAS_TERM_'):
            parts.append(part)  # Leave placeholder unchanged
        else:
            parts.append(part.lower())
    text = ''.join(parts)

    # Remove special characters (except spaces and placeholders)
    parts = []
    for part in re.split(r'(ADIDAS_TERM_\d+_\d+)', text):
        if part.startswith('ADIDAS_TERM_'):
            parts.append(part)
        else:
            cleaned = re.sub(r'[^a-zA-Z\s]', '', part)
            parts.append(cleaned)
    text = ''.join(parts)

    # Remove extra whitespace (but keep spaces around placeholders)
    text = re.sub(r'\s+', ' ', text).strip()

    # Restore brand terms
    return restore_brand_terms(text, placeholders)


def load_dataset(input_file):
    """Load dataset from CSV file"""
    df = pd.read_csv(input_file)
    df['comment'] = df['comment'].fillna('')  # Handle missing values
    return df


def save_dataset(df, output_file):
    """Save processed dataset to Excel"""
    try:
        # Ensure the file has .xlsx extension
        if not output_file.endswith('.xlsx'):
            output_file = output_file.replace('.csv', '.xlsx')

        df.to_excel(output_file, index=False, engine='openpyxl')
        print(f"Dataset saved to {output_file}")
    except Exception as e:
        print(f"Error saving to Excel, trying CSV instead: {str(e)}")
        csv_file = output_file.replace('.xlsx', '.csv')
        df.to_csv(csv_file, index=False)
        print(f"Saved to CSV instead: {csv_file}")


def preprocess_dataset(input_file, output_file):
    """Main function to load, preprocess and save dataset"""
    # Load data
    df = load_dataset(input_file)

    # Remove duplicates
    df.drop_duplicates(subset=['comment'], inplace=True)

    # Clean text (expanding contractions and general cleaning)
    df['cleaned_comment'] = df['comment'].apply(lambda x: clean_text(expand_contractions(x)))

    # Save processed data
    save_dataset(df, output_file)
    return df


if __name__ == '__main__':
    #input_csv = 'train_dataset_adidas_youtube_labelled.csv'
    input_csv = 'test_dataset_adidas_youtube_labelled.csv'
    #output_file = 'train_dataset_adidas_youtube_preprocessed.xlsx'
    output_file = 'test_dataset_adidas_youtube_preprocessed.xlsx'
    processed_df = preprocess_dataset(input_csv, output_file)