import pandas as pd

# Load your full dataset
df = pd.read_csv("train_dataset_adidas_youtube.csv")

# Drop rows with any missing values (optional and safer for RapidMiner)
clean_df = df.dropna()

# Export all columns with UTF-8 encoding and proper quotes
clean_df.to_csv("train_dataset_adidas_youtube_cleaned.csv", index=False, encoding='utf-8', quoting=1)
